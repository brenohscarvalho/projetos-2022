import java.util.List;

class Casa extends Imovel {
    private float seguroIncendio;

    public Casa(float valorVenda, String endereco, int anoConstrucao, List<String> beneficios, float seguroIncendio) {
        super(valorVenda, endereco, anoConstrucao, beneficios);
        this.seguroIncendio = seguroIncendio;
    }

    @Override
    public float calcularValorAluguelBase() {
        return valorVenda * 0.005f;
    }

    @Override
    public float descontoPorIdade() {
        return 0.1f;
    }

    @Override
    public float calcularAcrescimos() {
        return seguroIncendio / 12;
    }
}