import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ImobiliariaSistema {

    public static void main(String[] args) {
        // Cria uma lista de benefícios para casas e apartamentos
        List<String> beneficiosCasa = new ArrayList<>(Arrays.asList("Piscina", "Área de lazer"));
        List<String> beneficiosApt = new ArrayList<>(Arrays.asList("Área privativa", "Elevador"));

        // Cria objetos Casa e Apartamento
        Casa casa1 = new Casa(850000, "Rua joão carneiro 41", 2013, beneficiosCasa, 300);
        Apartamento apt1 = new Apartamento(600000, "Jardim America 1326", 2013, beneficiosApt, 200);

        Imobiliaria imobiliaria = new Imobiliaria(0.12f);

        imobiliaria.adicionarImovel(casa1);
        imobiliaria.adicionarImovel(apt1);

        float ganho = imobiliaria.calcularGanhoTotal();
        System.out.println("Ganho total da imobiliária: " + ganho);

        System.out.println("\nValores arrecadados e valores líquidos:");
        imobiliaria.mostrarValoresArrecadados();
    }
}