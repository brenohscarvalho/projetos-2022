import java.util.ArrayList;
import java.util.List;

class Imobiliaria {
    private List<Imovel> imoveis;
    private float comissao;

    public Imobiliaria(float comissao) {
        this.comissao = comissao;
        this.imoveis = new ArrayList<>();
    }

    public void adicionarImovel(Imovel imovel) {
        imoveis.add(imovel);
    }

    public float calcularValorRecebido(Imovel imovel) {
        return imovel.calcularValorAluguel() * comissao;
    }

    public float calcularGanhoTotal() {
        float ganhoTotal = 0;
        for (Imovel imovel : imoveis) {
            ganhoTotal += calcularValorRecebido(imovel);
        }
        return ganhoTotal;
    }

    public void mostrarValoresArrecadados() {
        for (Imovel imovel : imoveis) {
            float valorArrecadado = imovel.calcularValorAluguel();
            float valorLiquido = valorArrecadado - calcularValorRecebido(imovel);
            System.out.println("Endereço: " + imovel.endereco);
            System.out.println("Valor arrecadado: " + valorArrecadado);
            System.out.println("Valor líquido do repasse: " + valorLiquido);
            System.out.println();
        }
    }
}