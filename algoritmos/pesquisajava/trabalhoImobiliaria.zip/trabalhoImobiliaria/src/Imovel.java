import java.util.List;

abstract class Imovel {
    protected float valorVenda;
    protected String endereco;
    protected int anoConstrucao;
    protected List<String> beneficios;

    public Imovel(float valorVenda, String endereco, int anoConstrucao, List<String> beneficios) {
        this.valorVenda = valorVenda;
        this.endereco = endereco;
        this.anoConstrucao = anoConstrucao;
        this.beneficios = beneficios;
    }

    public abstract float calcularValorAluguelBase();

    public float calcularDesconto() {
        int idade = 2023 - anoConstrucao;
        float desconto = 0;
        for (int i = 0; i < idade / 5; i++) {
            desconto += calcularValorAluguelBase() * descontoPorIdade();
            if (desconto >= calcularValorAluguelBase() * 0.3) {
                break;
            }
        }
        return desconto;
    }

    public abstract float descontoPorIdade();

    public abstract float calcularAcrescimos();

    public float calcularValorAluguel() {
        return calcularValorAluguelBase() - calcularDesconto() + calcularAcrescimos();
    }
}