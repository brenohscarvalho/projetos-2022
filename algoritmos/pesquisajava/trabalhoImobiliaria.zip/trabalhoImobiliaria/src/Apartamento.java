import java.util.List;

class Apartamento extends Imovel {
    private float taxaCondominio;

    public Apartamento(float valorVenda, String endereco, int anoConstrucao, List<String> beneficios,
            float taxaCondominio) {
        super(valorVenda, endereco, anoConstrucao, beneficios);
        this.taxaCondominio = taxaCondominio;
    }

    @Override
    public float calcularValorAluguelBase() {
        return valorVenda * 0.004f;
    }

    @Override
    public float descontoPorIdade() {
        return 0.05f;
    }

    @Override
    public float calcularAcrescimos() {
        return taxaCondominio;
    }
}
